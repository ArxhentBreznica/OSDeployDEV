# Introduction 
This project is being used to develop installations via PSADT.
To make this application work properly, please enter the following detection method details. These will be used in the process of creating the Intune application. If this installation doesn't include an executable, please leave it empty.

# Detection Method Details
EXE Source Path:
EXE File Name:
EXE File Version:

# Detection Method Example:
EXE Source Path: C:\Program Files (x86)\Abacus\AbaClient\bin
EXE File Name: abaclientmanager.exe
EXE File Version: 2.3.730.0

# Build and Test
To test your script, please use a sandbox.
To create the test application, use the function "Create-TestApplication". This function will create the Intune application and - if nonexistent yet - a new AAD group.
If these tests were successful, assign the Intune application to the Prod AAD group.